---
name: english-article-viewer
description: Build a WorkBuddy-compatible local interactive English reading/writing course page with Pre-reading lead-in, title prediction, blocking-word cards, While-reading gist/detail/vocabulary activities, and responsive post-reading activities. Use when the user wants an Instructions and Plain English learning worksheet; do not use for arbitrary article rendering or when article/course input is missing.
metadata:
  version: "1.1.0"
---

# Instructions and Plain English Course Page

This WorkBuddy-compatible skill builds a local HTML learning worksheet from the provided JSON input. It presents a Pre-reading page with Lead-in, Predict, and Blocking Words, followed by an interactive While-reading page and five post-reading activities. All questions and vocabulary must be written from the supplied article, never copied from a fixed unrelated template.

## Input and build

Require a JSON file containing a non-empty title, at least one non-empty paragraph, article analysis, a `preReading` object, a `whileReading` object, and exactly five `postReading.activities`. `preReading` must contain `leadIn` and `predict` questions with reference answers and purposes, plus at least one `blockingWords` item with an English definition. `whileReading.paragraphGists` must contain one gist per paragraph, `detailQuestions` exactly five text-supported True/False items with explanations, and `vocabulary` exactly ten terms with English definitions. Each post-reading activity must include a label, question, purpose, thinking, connection, and (when needed) placeholder. The source is validated internally and used to generate the HTML. If article text, analysis, or a question is missing, stop; do not invent facts or attribute unsupported views to the author.

For each new article, first identify the core idea, core issue/debate, views presented, real-world value, and target vocabulary. Then create exactly five questions in this order: reflection/prediction, personal and wider-world connection, practical situation and action plan, open position with reasons and an example, and a concise exit sentence. Keep the English natural for the stated learner level and do not provide answer keys unless requested.

From this skill directory, run:

    node scripts/build.js <article.json> <output_dir>

The build reads the supplied article's `title` and creates `<output_dir>/<title>.html` plus `<output_dir>/<title>.zip`. The ZIP contains only that HTML file. In WorkBuddy, return or attach only the title-named HTML file; do not output the source JSON, design notes, validation result, build record, ZIP, or any other generated file.

## Validate and package

Run:

    node scripts/validate.js <article.json> <output_dir>

Then package the skill:

    node scripts/package_skill.js

This creates `dist/english-article-viewer.zip` for GitHub upload. The package name is fixed for the skill; the generated lesson HTML name remains dynamic and comes from the supplied article title.

Validation checks the source contract, exactly five article-based questions, and the generated HTML. It does not create or require additional deliverable files.

## Page behavior

- Warm paper background, deep teal lesson header, serif headings, responsive cards, and accessible form controls.
- Pre-reading contains exactly three vertical parts: Lead-in, Predict, and Blocking Words. Lead-in activates the article theme; Predict uses the title; each question has a student response box between the question and the hidden reference-answer button. Blocking Words are not the lesson's target vocabulary and flip in place to reveal readable English definitions when their cards are clicked.
- Use the supplied article's actual `title` as the page `<title>` and the large top heading. Keep `Instructions and Plain English` as the course label, not as a replacement for the article title.
- Stage tabs are real buttons. While-reading opens by default and contains Reading all plus reading gist details. Reading all shows the marked article, a four-option main-idea question, and shuffled paragraph-gist matching. reading gist details shows scrollable paragraph tabs, five True/False detail questions, and ten shuffled vocabulary-definition matching items.
- Matching tasks use green feedback for correct pairs and red feedback for incorrect pairs; Reset clears current choices. Reference answers are hidden until the teacher clicks the answer button.
- While-reading paragraph-gist matching and vocabulary matching each have their own Reset button. Clicking a card highlights the current selection; a correct word/meaning pair turns both cards green, and an incorrect pair turns both cards red.
- In Reading gist & details, True / False detail checks are placed in the upper part of the right column, with vocabulary matching below them. Selected and feedback states keep dark readable text on colored cards.
- Both sides of the paragraph-gist and vocabulary matching tasks are shuffled independently. The first click selects a card, a second click on that same card cancels the selection, and a correct pair turns green.
- Reading all keeps the paragraph cards in numerical order while shuffling the gist answers. True / False detail checks have their own Reset button, which clears selected answers and feedback.
- Each matching task also has a Reset incorrect button beside Reset; it clears only incorrectly matched cards and leaves correct green pairs unchanged.
- Speaking uses a two-column grid at 768px and above, then stacks on smaller screens.
- Voice is a local select placeholder. Edit toggles its visible state. Export downloads current textarea/radio responses as JSON; it does not claim to save to a server.
- Never invent article facts: derive the lead-in, prediction answer, gists, statements, explanations, definitions, and blocking words from the supplied article.

## Boundaries

- Do not modify projects outside this skill directory.
- Do not manually edit generated HTML; edit `assets/article.html.template`, then rebuild and validate.
- Do not claim real voice playback, account persistence, or backend export.
- Use the supplied source JSON only as validated input; do not expose it as a separate WorkBuddy deliverable.
- Final WorkBuddy delivery is HTML-only: provide the HTML file named from the supplied article title and no other output files.
