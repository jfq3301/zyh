#!/usr/bin/env node
const fs = require("fs");
const path = require("path");
const { readArticle, fileStem } = require("./build");

function fail(message) {
  throw new Error(message);
}

function validate(inputPath, outputDir) {
  const article = readArticle(inputPath);
  const stem = fileStem(article.title);
  const htmlPath = path.join(outputDir, stem + ".html");
  const zipPath = path.join(outputDir, stem + ".zip");

  if (!fs.existsSync(htmlPath) || fs.statSync(htmlPath).size === 0) {
    fail("Missing or empty HTML output: " + htmlPath);
  }
  if (!fs.existsSync(zipPath) || fs.statSync(zipPath).size === 0) {
    fail("Missing or empty ZIP output: " + zipPath);
  }
  const html = fs.readFileSync(htmlPath, "utf8");
  if (!html.includes("Instructions and Plain English")) {
    fail("HTML is missing the course title.");
  }
  ["tab-pre", "tab-while", "tab-post", "panel-pre", "panel-while", "panel-post", "activities", "pre-reading"].forEach((id) => {
    if (!html.includes(`id="${id}"`)) fail("HTML is missing required course element: " + id);
  });
  [article.preReading.leadIn.question, article.preReading.predict.question, ...article.preReading.blockingWords.map(item => item.word)].forEach((text) => {
    if (!html.includes(text)) fail("HTML is missing Pre-reading content: " + text);
  });
  ["subtab-all", "subtab-details", "sub-all", "sub-details", "para-options", "gist-options", "paragraph-text", "term-options", "definition-options"].forEach((id) => {
    if (!html.includes(`id="${id}"`)) fail("HTML is missing required While-reading element: " + id);
  });
  if (!html.includes("True or False") || !html.includes("Show reference answer")) fail("HTML is missing reference-answer controls.");
  if (!html.includes("student-answer-label") || !html.includes("student-answer")) fail("HTML is missing the Pre-reading student response fields.");
  if (!html.includes("flip-face back") || !html.includes("definition") || !html.includes("addPreReadingControls")) fail("HTML is missing the Blocking Words flip interaction.");
  if (!html.includes("match-reset") || !html.includes("match-option.selected") || !html.includes("bindMatchReset")) fail("HTML is missing matching reset and selection feedback.");
  if (!html.includes("moveDetailChecks") || !html.includes("True or False") || !html.includes("details-card:last-child")) fail("HTML is missing the right-column detail-check layout.");
  if (!html.includes("shuffleMatchCards") || !html.includes("selected===card")) fail("HTML is missing shuffled matching cards and selection toggle behavior.");
  if (!html.includes("addDetailReset") || !html.includes("detail-reset") || !html.includes("list.id==='para-options'")) fail("HTML is missing the detail reset or ordered paragraph cards.");
  if (!html.includes("addIncorrectResetButtons") || !html.includes("Reset incorrect") || !html.includes("incorrect-reset")) fail("HTML is missing the incorrect-pair reset control.");
  if (article.whileReading.vocabulary.length !== 10) fail("While-reading vocabulary must contain exactly ten items.");
  ["Check your prediction", "Speaking", "Text-to-Self", "Text-to-World", "Exit ticket"].forEach((text) => {
    if (!html.includes(text)) fail("HTML is missing required activity: " + text);
  });
  article.postReading.activities.forEach((activity) => {
    if (!html.includes(activity.question)) fail("Generated HTML is missing question: " + activity.question);
  });
  if (html.includes("__INITIAL_DATA_JSON__") || html.includes("__TITLE_ESC__")) {
    fail("HTML still contains a template placeholder.");
  }

  const zipEntries = require("child_process").execFileSync("unzip", ["-Z1", zipPath], { encoding: "utf8" })
    .split(/\r?\n/).filter(Boolean);
  if (zipEntries.length !== 1 || zipEntries[0] !== stem + ".html") {
    fail("ZIP must contain only " + stem + ".html");
  }

  const result = {
    ok: true,
    html: path.resolve(htmlPath),
    zip: path.resolve(zipPath),
    title: article.title,
    paragraphs: article.paragraphs.length,
    postReadingQuestions: article.postReading.activities.length,
    checkedAt: new Date().toISOString(),
    missingContentPolicy: "reject; do not auto-complete",
    deliverable: "title-named HTML; ZIP contains only that HTML"
  };
  fs.writeFileSync(
    path.join(outputDir, "validation-result.json"),
    JSON.stringify(result, null, 2)
  );
  console.log(JSON.stringify(result, null, 2));
  return result;
}

const args = process.argv.slice(2);
if (args.length !== 2) {
  console.error("Usage: node scripts/validate.js <article.json> <output_dir>");
  process.exit(1);
}

try {
  validate(args[0], args[1]);
} catch (error) {
  const result = {
    ok: false,
    error: error.message,
    checkedAt: new Date().toISOString()
  };
  console.error(JSON.stringify(result, null, 2));
  process.exit(1);
}

module.exports = { validate };
