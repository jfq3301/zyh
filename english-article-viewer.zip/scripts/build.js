#!/usr/bin/env node
const fs = require("fs");
const path = require("path");
const { execFileSync } = require("child_process");

function fail(message) {
  throw new Error(message);
}

function readArticle(inputPath) {
  if (!fs.existsSync(inputPath)) fail("Input JSON does not exist: " + inputPath);
  let value;
  try {
    value = JSON.parse(fs.readFileSync(inputPath, "utf8"));
  } catch (error) {
    fail("Input JSON is invalid: " + error.message);
  }

  if (!value || typeof value !== "object" || Array.isArray(value)) {
    fail("Article root must be an object.");
  }
  if (typeof value.title !== "string" || value.title.trim() === "") {
    fail("Article title is missing or empty. The builder will not invent it.");
  }
  if (!Array.isArray(value.paragraphs) || value.paragraphs.length === 0) {
    fail("Article paragraphs must be a non-empty array. The builder will not invent paragraphs.");
  }
  value.paragraphs.forEach((paragraph, index) => {
    if (typeof paragraph !== "string" || paragraph.trim() === "") {
      fail("Paragraph " + (index + 1) + " is missing or empty. Complete the source article first.");
    }
  });

  if (!value.preReading || !value.preReading.leadIn || !value.preReading.predict || !Array.isArray(value.preReading.blockingWords) || value.preReading.blockingWords.length === 0) {
    fail("preReading must include leadIn, predict, and at least one blocking word.");
  }
  ["leadIn", "predict"].forEach((key) => {
    const item = value.preReading[key];
    if (!item.question || !item.answer || !item.purpose) {
      fail("preReading." + key + " needs question, answer, and purpose.");
    }
  });
  value.preReading.blockingWords.forEach((item, index) => {
    if (!item || !item.word || !item.definition) {
      fail("Blocking word " + (index + 1) + " needs word and definition.");
    }
  });

  if (!value.postReading || !Array.isArray(value.postReading.activities) || value.postReading.activities.length !== 5) {
    fail("postReading.activities must contain exactly five article-based questions.");
  }
  if (!value.analysis || !value.analysis.coreIdea || !value.analysis.coreIssue || !Array.isArray(value.analysis.differentViews) || !value.analysis.realWorldValue || !Array.isArray(value.analysis.targetVocabulary)) {
    fail("analysis must include coreIdea, coreIssue, differentViews, realWorldValue, and targetVocabulary.");
  }
  if (!value.whileReading || !Array.isArray(value.whileReading.paragraphGists) || value.whileReading.paragraphGists.length !== value.paragraphs.length || !Array.isArray(value.whileReading.detailQuestions) || value.whileReading.detailQuestions.length !== 5 || !Array.isArray(value.whileReading.vocabulary) || value.whileReading.vocabulary.length !== 10) {
    fail("whileReading must include one gist per paragraph, exactly five detail questions, and exactly ten vocabulary items.");
  }
  value.whileReading.paragraphGists.forEach((item, index) => {
    if (!item || item.paragraph !== index + 1 || typeof item.gist !== "string" || item.gist.trim() === "") fail("whileReading.paragraphGists must cover paragraphs in order.");
  });
  value.whileReading.detailQuestions.forEach((item, index) => {
    if (!item || item.number !== index + 1 || typeof item.statement !== "string" || typeof item.answer !== "boolean" || !item.explanation) fail("Each while-reading detail question needs number, statement, boolean answer, and explanation.");
  });
  value.whileReading.vocabulary.forEach((item, index) => {
    if (!item || typeof item.term !== "string" || !item.term.trim() || typeof item.definition !== "string" || !item.definition.trim()) fail("Each while-reading vocabulary item needs a term and definition.");
  });
  value.postReading.activities.forEach((activity, index) => {
    if (!activity || typeof activity.question !== "string" || activity.question.trim() === "") {
      fail("Post-reading question " + (index + 1) + " is missing or empty.");
    }
    if (!activity.purpose || !activity.thinking || !activity.connection) {
      fail("Post-reading question " + (index + 1) + " needs purpose, thinking, and connection notes.");
    }
  });

  return value;
}

function escapeHtml(value) {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function fileStem(title) {
  const stem = String(title)
    .trim()
    .replace(/[\\/:*?"<>|\u0000-\u001f]/g, "_")
    .replace(/\s+/g, " ")
    .replace(/[. ]+$/g, "");
  if (!stem) fail("Article title cannot be used as a file name.");
  return stem;
}

function buildDesignNotes(article) {
  const analysis = article.analysis;
  const sections = [
    "# Pre-reading, While-reading, and Post-reading Design Notes\n",
    "## A. Article analysis\n",
    `- **Core idea:** ${analysis.coreIdea}`,
    `- **Core issue or debate:** ${analysis.coreIssue}`,
    `- **Different views:** ${analysis.differentViews.join(" ")}`,
    `- **Real-world value:** ${analysis.realWorldValue}`,
    `- **Target vocabulary:** ${analysis.targetVocabulary.join(", ")}`,
    "\n## B. Pre-reading design\n",
    `- **Lead-in:** ${article.preReading.leadIn.question}`,
    `- **Lead-in purpose:** ${article.preReading.leadIn.purpose}`,
    `- **Prediction:** ${article.preReading.predict.question}`,
    `- **Prediction purpose:** ${article.preReading.predict.purpose}`,
    `- **Blocking words:** ${article.preReading.blockingWords.map(item => `${item.word} — ${item.definition}`).join(" | ")}`,
    "- **Question quality check:** Both questions are text-supported, have different purposes, fit the learner level, and can be answered meaningfully without outside information.",
    "\n## C. While-reading design\n",
    `- **Paragraph gist matching:** ${article.whileReading.paragraphGists.map(item => `P${item.paragraph}: ${item.gist}`).join(" | ")}`,
    `- **Detail checks:** ${article.whileReading.detailQuestions.map(item => `${item.number}. ${item.answer ? "True" : "False"}`).join(", ")}`,
    `- **Vocabulary:** ${article.whileReading.vocabulary.map(item => item.term).join(", ")}`,
    "- **Quality check:** The five statements are text-supported, use different detail-reading purposes, and require no outside knowledge.",
    "\n## D. Five post-reading questions\n",
    ...article.postReading.activities.map((activity, index) => `${index + 1}. **${activity.label}** ${activity.question}`),
    "\n## E. Design basis\n",
    ...article.postReading.activities.map((activity, index) => `### ${index + 1}. ${activity.label}\n- **Teaching purpose:** ${activity.purpose}\n- **Thinking skill:** ${activity.thinking}\n- **Connection to the article:** ${activity.connection}`),
    "\n## F. Quality check\n",
    "- Exactly five questions are present and each is tied to the supplied article.",
    "- The sequence covers reflection, transfer, practical application, argumentation, and concise English output.",
    "- No reference answers are included."
  ];
  return sections.join("\n");
}

function build(inputPath, outputDir) {
  const article = readArticle(inputPath);
  const stem = fileStem(article.title);
  const skillRoot = path.resolve(__dirname, "..");
  const templatePath = path.join(skillRoot, "assets", "article.html.template");
  const template = fs.readFileSync(templatePath, "utf8");
  const html = template
    .replace(/__TITLE_ESC__/g, escapeHtml(article.title))
    .replace("__INITIAL_DATA_JSON__", JSON.stringify(article))
    .replace("renderPre();document.getElementById('sub-all')", "renderPre();document.querySelectorAll('[data-key]').forEach((button)=>{const key=document.getElementById(button.dataset.key+'-key');if(key)key.id=button.dataset.key});document.getElementById('sub-all')");

  fs.mkdirSync(outputDir, { recursive: true });
  const htmlPath = path.join(outputDir, stem + ".html");
  const zipPath = path.join(outputDir, stem + ".zip");
  fs.writeFileSync(htmlPath, html);
  execFileSync("zip", ["-q", "-j", "-FS", zipPath, htmlPath], { stdio: "inherit" });

  console.log(JSON.stringify({
    ok: true,
    title: article.title,
    html: path.resolve(htmlPath),
    zip: path.resolve(zipPath),
    paragraphs: article.paragraphs.length
  }, null, 2));
}

if (require.main === module) {
  const args = process.argv.slice(2);
  if (args.length !== 2) {
    console.error("Usage: node scripts/build.js <article.json> <output_dir>");
    process.exit(1);
  }

  try {
    build(args[0], args[1]);
  } catch (error) {
    console.error("Build failed: " + error.message);
    process.exit(1);
  }
}

module.exports = { readArticle, build, escapeHtml, buildDesignNotes, fileStem };
