#!/usr/bin/env node
const fs = require("fs");
const path = require("path");
const { execFileSync } = require("child_process");

const skillRoot = path.resolve(__dirname, "..");
const version = fs.readFileSync(path.join(skillRoot, "VERSION"), "utf8").trim();
const outDir = path.join(skillRoot, "dist");
const zipPath = path.join(outDir, "english-article-viewer.zip");

if (!fs.existsSync(path.join(skillRoot, "SKILL.md"))) {
  throw new Error("SKILL.md is missing.");
}
if (!fs.existsSync(path.join(skillRoot, "manifest.yaml"))) {
  throw new Error("manifest.yaml is missing.");
}

fs.mkdirSync(outDir, { recursive: true });
if (fs.existsSync(zipPath)) fs.unlinkSync(zipPath);

execFileSync("zip", [
  "-r",
  zipPath,
  ".",
  "-x", "./dist/*",
  "-x", "./verification-output/*",
  "-x", "./output/*",
  "-x", "./credential.txt",
  "-x", "./SKILL.md.bak",
  "-x", "*/.git/*",
  "-x", "*/.DS_Store"
], { cwd: skillRoot, stdio: "inherit" });

console.log(JSON.stringify({
  ok: true,
  version,
  zip: zipPath
}, null, 2));
